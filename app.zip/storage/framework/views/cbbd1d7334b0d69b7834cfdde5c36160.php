<!DOCTYPE html>
<html lang="en" data-theme="<?php echo e(Cookie::get('theme', 'light')); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Login'); ?> - Laravel Admin</title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/dark-mode.css')); ?>">
</head>
<body class="auth-body">
    <div class="auth-container">
        <!-- Theme Toggle for Auth Pages -->
        <div class="auth-theme-toggle">
            <button class="theme-toggle" id="themeToggle">
                <i class="bi bi-moon"></i>
            </button>
        </div>

        <!-- Auth Content -->
        <div class="auth-card">
            <div class="auth-header">
                <?php echo $__env->yieldContent('auth-header'); ?>
            </div>

            <div class="auth-content">
                <?php echo $__env->yieldContent('auth-content'); ?>
            </div>

            <div class="auth-footer">
                <?php echo $__env->yieldContent('auth-footer'); ?>
            </div>
        </div>

        <!-- Background Elements -->
        <div class="auth-bg-elements">
            <div class="bg-circle bg-circle-1"></div>
            <div class="bg-circle bg-circle-2"></div>
            <div class="bg-circle bg-circle-3"></div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Custom JS -->
    <script src="<?php echo e(asset('js/auth.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\xampp2024\htdocs\astrology\resources\views/layouts/auth.blade.php ENDPATH**/ ?>
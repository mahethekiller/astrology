<?php $__env->startSection('title', 'Create Role'); ?>
<?php $__env->startSection('page-title', 'Create Role'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="component-card">
            <h4>Create New Role</h4>
            <form method="POST" action="<?php echo e(route('admin.roles.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group-custom">
                    <label class="form-label-custom" for="name">Role Name *</label>
                    <input type="text" class="form-control-custom <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           id="name" name="name" value="<?php echo e(old('name')); ?>" required
                           placeholder="Enter role name (e.g., admin, manager)">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group-custom">
                    <label class="form-label-custom mb-3">Permissions</label>
                    <div class="permissions-container">
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module => $modulePermissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="permission-module mb-4">
                            <h6 class="text-muted mb-3 border-bottom pb-2">
                                <i class="bi bi-folder me-2"></i><?php echo e(ucfirst($module)); ?> Permissions
                            </h6>
                            <div class="row">
                                <?php $__currentLoopData = $modulePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 mb-3">
                                    <div class="form-check permission-checkbox">
                                        <input class="form-check-input" type="checkbox"
                                               name="permissions[]" value="<?php echo e($permission->id); ?>"
                                               id="permission_<?php echo e($permission->id); ?>"
                                               <?php echo e(in_array($permission->id, old('permissions', [])) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="permission_<?php echo e($permission->id); ?>">
                                            <div class="fw-medium"><?php echo e($permission->name); ?></div>
                                        </label>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="d-flex gap-2 mt-4">
                    <button type="submit" class="btn-custom btn-primary-custom">
                        <i class="bi bi-check-lg me-2"></i>Create Role
                    </button>
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn-custom btn-outline-secondary-custom">
                        <i class="bi bi-arrow-left me-2"></i>Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp2024\htdocs\astrology\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Astrology Blogs'); ?>

<?php $__env->startSection('content'); ?>
    <div class="section1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="title1 text-center">Latest Astrology Blogs</h1>
                    <div class="headingDeign text-center"><img src="<?php echo e(asset('frontend/images/headingDesign.png')); ?>" />
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section7">
        <div class="container">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="blogBox">
                            <div class="blogImg">
                                <a href="<?php echo e(route('blog.show', $blog->slug)); ?>">
                                    <?php if($blog->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $blog->image)); ?>"
                                            alt="<?php echo e($blog->image_alt ?? $blog->title); ?>"
                                            style="width: 100%; height: 250px; object-fit: cover; border-radius: 20px;" />
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('frontend/images/blog1.jpg')); ?>" alt="Blog"
                                            style="width: 100%; height: 250px; object-fit: cover; border-radius: 20px;" />
                                    <?php endif; ?>
                                </a>
                            </div>
                            <div class="dateandAstroaura">
                                <div class="blogDate"><img src="<?php echo e(asset('frontend/images/date.png')); ?>" />
                                    <?php echo e($blog->published_at ? $blog->published_at->format('D, M d, Y') : ''); ?></div>
                                <div class="astroaura"><img src="<?php echo e(asset('frontend/images/astroicon.png')); ?>" />
                                    <?php echo e($blog->author); ?></div>
                            </div>
                            <div class="blogTitle">
                                <a href="<?php echo e(route('blog.show', $blog->slug)); ?>"><?php echo e($blog->title); ?></a>
                            </div>
                            <div class="blogreadmorebtn">
                                <a href="<?php echo e(route('blog.show', $blog->slug)); ?>"><img
                                        src="<?php echo e(asset('frontend/images/readmorearrow.png')); ?>" /></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center">
                        <p>No blogs found.</p>
                    </div>
                <?php endif; ?>
            </div>
            <div class="row mt-4">
                <div class="col-12">
                    <?php echo e($blogs->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp2024\htdocs\astrology\resources\views/frontend/pages/blogs.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', $blog->meta_title ?? $blog->title); ?>
<?php $__env->startSection('meta_description', $blog->meta_description ?? Str::limit(strip_tags($blog->content), 160)); ?>

<?php $__env->startSection('content'); ?>
    <div class="section1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="title1 text-center"><?php echo e($blog->title); ?></h1>
                    <div class="headingDeign text-center"><img src="<?php echo e(asset('frontend/images/headingDesign.png')); ?>" />
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section7">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="blog-details">
                        <div class="blog-image mb-4">
                            <?php if($blog->image): ?>
                                <img src="<?php echo e(asset('storage/' . $blog->image)); ?>" alt="<?php echo e($blog->title); ?>"
                                    class="img-fluid w-100" style="border-radius: 20px;">
                            <?php else: ?>
                                <img src="<?php echo e(asset('frontend/images/blog1.jpg')); ?>" alt="" class="img-fluid w-100"
                                    style="border-radius: 20px;">
                            <?php endif; ?>
                        </div>
                        <div class="blog-meta d-flex justify-content-between mb-4">
                            <div class="date"><img src="<?php echo e(asset('frontend/images/date.png')); ?>" />
                                <?php echo e($blog->published_at ? $blog->published_at->format('D, M d, Y') : ''); ?></div>
                            <div class="author"><img src="<?php echo e(asset('frontend/images/astroicon.png')); ?>" />
                                <?php echo e($blog->author); ?></div>
                        </div>
                        <div class="blog-content">
                            <?php echo nl2br(e($blog->content)); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp2024\htdocs\astrology\resources\views/frontend/pages/blog-details.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Sliders'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">Sliders</h3>
                    <a href="<?php echo e(route('admin.sliders.create')); ?>" class="btn btn-primary">Add New Slider</a>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Image</th>
                                <th>Title</th>
                                <th>Group</th>
                                <th>Order</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($slider->id); ?></td>
                                <td>
                                    <img src="<?php echo e(Storage::url($slider->image)); ?>" alt="<?php echo e($slider->title); ?>" width="80" height="50" style="object-fit: cover;">
                                </td>
                                <td><?php echo e($slider->title ?? 'No Title'); ?></td>
                                <td>
                                    <span class="badge bg-info"><?php echo e($slider->group); ?></span>
                                </td>
                                <td><?php echo e($slider->order); ?></td>
                                <td>
                                    <form action="<?php echo e(route('admin.sliders.toggle-status', $slider)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-sm <?php echo e($slider->is_active ? 'btn-success' : 'btn-secondary'); ?>">
                                            <?php echo e($slider->is_active ? 'Active' : 'Inactive'); ?>

                                        </button>
                                    </form>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.sliders.edit', $slider)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <form action="<?php echo e(route('admin.sliders.destroy', $slider)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>


                </div>
                <div class="d-flex p-2 ">
                        <?php echo e($sliders->links()); ?>

                    </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp2024\htdocs\astrology\resources\views/admin/sliders/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('auth-header'); ?>
    <div class="auth-logo">
        <i class="bi bi-layout-text-window-reverse"></i>
        <h1>Laravel Admin</h1>
    </div>
    <div>
        <h2 class="auth-title">Welcome Back</h2>
        <p class="auth-subtitle">Please sign in to your account</p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('auth-content'); ?>
    <!-- Display Success Message -->
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <i class="bi bi-check-circle me-2"></i>
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <!-- Display Error Message -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <i class="bi bi-exclamation-circle me-2"></i>
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>

    <form class="auth-form" method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label class="form-label" for="email">Email Address</label>
            <div class="input-group">
                <input type="email"
                       class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       id="email"
                       name="email"
                       value="<?php echo e(old('email')); ?>"
                       placeholder="Enter your email"
                       required
                       autofocus>
                <div class="input-icon">
                    <i class="bi bi-envelope"></i>
                </div>
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger mt-1" style="font-size: 12px;">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label class="form-label" for="password">Password</label>
            <div class="input-group">
                <input type="password"
                       class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       id="password"
                       name="password"
                       placeholder="Enter your password"
                       required>
                <div class="input-icon">
                    <i class="bi bi-lock"></i>
                </div>
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger mt-1" style="font-size: 12px;">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-check">
            <input class="form-check-input" type="checkbox" id="remember" name="remember">
            <label class="form-check-label" for="remember">
                Remember me
            </label>
        </div>

        <button type="submit" class="auth-btn">
            <i class="bi bi-box-arrow-in-right me-2"></i>
            Sign In
        </button>
    </form>

    <div class="auth-divider">
        <span>Or continue with</span>
    </div>

    <div class="social-auth">
        <button type="button" class="social-btn google">
            <i class="bi bi-google"></i>
            Google
        </button>
        <button type="button" class="social-btn github">
            <i class="bi bi-github"></i>
            GitHub
        </button>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('auth-footer'); ?>
    <div class="auth-links">
        <?php if(Route::has('password.request')): ?>
            <a href="<?php echo e(route('password.request')); ?>" class="auth-link">
                <i class="bi bi-key me-1"></i>
                Forgot password?
            </a>
        <?php endif; ?>

        <?php if(Route::has('register')): ?>
            <a href="<?php echo e(route('register')); ?>" class="auth-link">
                <i class="bi bi-person-plus me-1"></i>
                Create account
            </a>
        <?php endif; ?>
    </div>

    <div style="text-align: center;">
        <small class="text-muted">
            &copy; <?php echo e(date('Y')); ?> Laravel Admin. All rights reserved.
        </small>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp2024\htdocs\astrology\resources\views/auth/login.blade.php ENDPATH**/ ?>
<div class="sidebar">
    <div class="sidebar-header">
        <h3><i class="bi bi-layout-text-window-reverse"></i> <span><?php echo e(config('app.name', 'Laravel')); ?></span></h3>
    </div>
    <div class="sidebar-menu">
        <ul>
            <!-- Role-specific dashboard links -->
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->isAdmin()): ?>
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>">
                            <i class="bi bi-speedometer2"></i> <span>Admin Dashboard</span>
                        </a>
                    </li>
                <?php elseif(auth()->user()->isManager()): ?>
                    <li>
                        <a href="<?php echo e(route('manager.dashboard')); ?>"
                            class="<?php echo e(request()->is('manager/dashboard') ? 'active' : ''); ?>">
                            <i class="bi bi-speedometer2"></i> <span>Manager Dashboard</span>
                        </a>
                    </li>
                <?php else: ?>
                    <li>
                        <a href="<?php echo e(route('user.dashboard')); ?>" class="<?php echo e(request()->is('user/dashboard') ? 'active' : ''); ?>">
                            <i class="bi bi-speedometer2"></i> <span>My Dashboard</span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>

            <!-- Common features accessible based on role -->
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->isAdmin() || auth()->user()->isManager()): ?>
                    <li>
                        <a href="<?php echo e(auth()->user()->isAdmin() ? route('admin.components') : route('manager.components')); ?>"
                            class="<?php echo e(request()->is('*/components') ? 'active' : ''); ?>">
                            <i class="bi bi-collection"></i> <span>Components</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(auth()->user()->isAdmin() ? route('admin.tables') : route('manager.tables')); ?>"
                            class="<?php echo e(request()->is('*/tables') ? 'active' : ''); ?>">
                            <i class="bi bi-table"></i> <span>Tables</span>
                        </a>
                    </li>



                <?php endif; ?>

                <!-- Admin Only Menu -->
                <?php if(auth()->user()->isAdmin()): ?>
                    <li class="menu-section">
                        <small class="text-uppercase text-muted">Administration</small>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.roles.index')); ?>" class="<?php echo e(request()->is('admin/roles*') ? 'active' : ''); ?>">
                            <i class="bi bi-shield-check"></i> <span>Role Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.permissions.index')); ?>"
                            class="<?php echo e(request()->is('admin/permissions*') ? 'active' : ''); ?>">
                            <i class="bi bi-key"></i> <span>Permission Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(auth()->user()->isAdmin() ? route('admin.sliders.index') : route('manager.sliders.index')); ?>"
                            class="<?php echo e(request()->is('*/sliders*') ? 'active' : ''); ?>">
                            <i class="bi bi-sliders"></i> <span>Sliders</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.newsletters.index')); ?>"
                            class="<?php echo e(request()->is('admin/newsletters*') ? 'active' : ''); ?>">
                            <i class="bi bi-envelope"></i> <span>Newsletters</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.testimonials.index')); ?>"
                            class="<?php echo e(request()->is('admin/testimonials*') ? 'active' : ''); ?>">
                            <i class="bi bi-chat-quote"></i> <span>Testimonials</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.blogs.index')); ?>" class="<?php echo e(request()->is('admin/blogs*') ? 'active' : ''); ?>">
                            <i class="bi bi-journal-text"></i> <span>Blogs</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.users.index')); ?>" class="<?php echo e(request()->is('admin/users*') ? 'active' : ''); ?>">
                            <i class="bi bi-people"></i> <span>User Management</span>
                        </a>
                    </li>




                    <li class="nav-item">
                        <a class="nav-link d-flex align-items-center dropdown-toggle
                                                    <?php echo e(request()->is('admin/astrologer-profiles*') || request()->is('admin/languages*') || request()->is('admin/specializations*') ? '' : 'collapsed'); ?>"
                            href="#astrologerMenu" data-bs-toggle="collapse" data-bs-target="#astrologerMenu"
                            aria-expanded="<?php echo e(request()->is('admin/astrologer-profiles*') || request()->is('admin/languages*') || request()->is('admin/specializations*') ? 'true' : 'false'); ?>"
                            aria-controls="astrologerMenu">
                            <i class="bi bi-stars me-2"></i>
                            <span>Astrologer Management</span>
                        </a>

                        <ul id="astrologerMenu"
                            class="collapse list-unstyled ps-3
                                                    <?php echo e(request()->is('admin/astrologer-profiles*') || request()->is('admin/languages*') || request()->is('admin/specializations*') ? 'show' : ''); ?>">
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.astrologer-profiles.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/astrologer-profiles*') ? 'active' : ''); ?>">
                                    <i class="bi bi-stars me-2"></i>
                                    Astrologers
                                </a>
                            </li>

                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.languages.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/languages*') ? 'active' : ''); ?>">
                                    <i class="bi bi-translate me-2"></i>
                                    Languages
                                </a>
                            </li>

                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.specializations.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/specializations*') ? 'active' : ''); ?>">
                                    <i class="bi bi-star me-2"></i>
                                    Specializations
                                </a>
                            </li>
                        </ul>
                    </li>



                <?php endif; ?>

                <!-- Manager Only Menu -->
                <?php if(auth()->user()->isManager()): ?>
                    <li class="menu-section">
                        <small class="text-uppercase text-muted">Management</small>
                    </li>
                    <li>
                        <a href="<?php echo e(route('manager.reports')); ?>" class="<?php echo e(request()->is('manager/reports') ? 'active' : ''); ?>">
                            <i class="bi bi-graph-up"></i> <span>Reports</span>
                        </a>
                    </li>
                <?php endif; ?>

                <!-- User Menu -->
                <?php if(auth()->user()->isUser()): ?>
                    <li class="menu-section">
                        <small class="text-uppercase text-muted">Personal</small>
                    </li>
                    <li>
                        <a href="<?php echo e(route('user.settings')); ?>" class="<?php echo e(request()->is('user/settings') ? 'active' : ''); ?>">
                            <i class="bi bi-gear"></i> <span>Settings</span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
        </ul>
    </div>
</div><?php /**PATH D:\xampp2024\htdocs\astrology\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>
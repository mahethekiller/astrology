<div class="row">
    @forelse($astrologers as $astrologer)
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="ourAstroBox">
                <span class="topAstroBoxactive"
                    style="background-color: {{ $astrologer->is_online ? 'green' : 'gray' }};"></span>

                <div class="ourAstroretingStar">
                    <i class="fa-solid fa-star"></i> {{ number_format($astrologer->rating, 1) }}
                </div>

                <div class="topAstroBoxImg">
                    <a href="{{ route('astrologer.show', $astrologer->id) }}">
                        <img src="{{ asset('uploads/astrologers/' . $astrologer->profile_image) }}"
                            alt="{{ $astrologer->display_name }}"
                            style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover;">
                    </a>
                </div>

                <div class="astroDetails">
                    <div class="topAstroName text-truncate" title="{{ $astrologer->display_name }}">
                        {{ $astrologer->display_name }}
                    </div>

                    <div class="ourAstroBoxflowBtn">
                        <a href="#">Follow</a>
                    </div>

                    <div class="ourastroLang text-truncate" title="{{ $astrologer->languages->pluck('name')->join(', ') }}">
                        {{ $astrologer->languages->pluck('name')->join(', ') }}
                    </div>

                    <div class="ourAstroWork text-truncate"
                        title="{{ $astrologer->specializations->pluck('name')->join(', ') }}">
                        {{ $astrologer->specializations->pluck('name')->join(', ') }}
                    </div>

                    <div class="ourtotalExp">Exp. : <strong>{{ $astrologer->experience_years }} Yrs</strong></div>

                    <div class="ourAstroChatbtn pt20">
                        <div class="totalExp">₹35/min</div>
                        <div class="totalExp">₹35/min</div>
                    </div>

                    <div class="ourAstroChatbtn">
                        <a class="ourAstrobtn" href="tel:+919876543210">
                            <img src="{{ asset('images/call2.png') }}" style="width: 16px; margin-right: 5px;">CALL
                        </a>
                        <a class="ourAstrobtn" href="#">
                            <img src="{{ asset('images/chat2.png') }}" style="width: 16px; margin-right: 5px;">CHAT
                        </a>
                    </div>

                </div>
            </div>
        </div>
    @empty
        <div class="col-12 text-center">
            <h4>No astrologers found matching your criteria.</h4>
        </div>
    @endforelse
</div>

<div class="row">
    <div class="col-12 d-flex justify-content-center">
        {{ $astrologers->links('pagination::bootstrap-5') }}
    </div>
</div>
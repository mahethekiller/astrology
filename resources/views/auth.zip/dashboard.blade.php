@extends('layouts.app')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard')

@section('content')
<!-- Stats Cards -->
<div class="row">
    <div class="col-md-3">
        <div class="dashboard-card">
            <div class="card-icon primary">
                <i class="bi bi-people"></i>
            </div>
            <div class="card-value">{{ number_format($stats['total_users']) }}</div>
            <div class="card-title">Total Users</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="dashboard-card">
            <div class="card-icon success">
                <i class="bi bi-cart-check"></i>
            </div>
            <div class="card-value">{{ number_format($stats['total_orders']) }}</div>
            <div class="card-title">Total Orders</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="dashboard-card">
            <div class="card-icon warning">
                <i class="bi bi-graph-up"></i>
            </div>
            <div class="card-value">${{ number_format($stats['total_revenue']) }}</div>
            <div class="card-title">Total Revenue</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="dashboard-card">
            <div class="card-icon danger">
                <i class="bi bi-eye"></i>
            </div>
            <div class="card-value">{{ number_format($stats['page_views']) }}</div>
            <div class="card-title">Page Views</div>
        </div>
    </div>
</div>

<!-- Recent Activity -->
<div class="row">
    <div class="col-12">
        <div class="table-container">
            <div class="table-header">
                <h3>Recent Orders</h3>
                <button class="btn btn-primary btn-sm">View All</button>
            </div>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($recent_orders as $order)
                        <tr>
                            <td>{{ $order['id'] }}</td>
                            <td>{{ $order['customer'] }}</td>
                            <td>{{ $order['date'] }}</td>
                            <td>${{ number_format($order['amount'], 2) }}</td>
                            <td>
                                <span class="badge bg-{{ $order['status'] == 'completed' ? 'success' : 'warning' }}">
                                    {{ ucfirst($order['status']) }}
                                </span>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@extends('layouts.app')

@section('title', 'UI Components')
@section('page-title', 'UI Components')

@section('content')
<div class="component-card">
    <h4>Buttons</h4>
    <div class="row g-3">
        <div class="col-12">
            <button class="btn btn-primary me-2">Primary</button>
            <button class="btn btn-secondary me-2">Secondary</button>
            <button class="btn btn-success me-2">Success</button>
            <button class="btn btn-warning me-2">Warning</button>
            <button class="btn btn-danger me-2">Danger</button>
        </div>
    </div>
</div>

<div class="component-card">
    <h4>Cards</h4>
    <div class="row">
        <div class="col-md-4">
            <div class="dashboard-card">
                <div class="card-icon primary">
                    <i class="bi bi-people"></i>
                </div>
                <div class="card-value">1,254</div>
                <div class="card-title">Total Users</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dashboard-card">
                <div class="card-icon success">
                    <i class="bi bi-cart-check"></i>
                </div>
                <div class="card-value">524</div>
                <div class="card-title">Total Orders</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dashboard-card">
                <div class="card-icon warning">
                    <i class="bi bi-graph-up"></i>
                </div>
                <div class="card-value">$12,850</div>
                <div class="card-title">Total Revenue</div>
            </div>
        </div>
    </div>
</div>
@endsection

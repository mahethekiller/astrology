<div class="sidebar">
    <div class="sidebar-header">
        <h3><i class="bi bi-layout-text-window-reverse"></i> <span>{{ config('app.name', 'Laravel') }}</span></h3>
    </div>
    <div class="sidebar-menu">
        <ul>
            <li>
                <a href="{{ route('dashboard') }}" class="{{ request()->routeIs('dashboard') ? 'active' : '' }}">
                    <i class="bi bi-speedometer2"></i> <span>Dashboard</span>
                </a>
            </li>

            @auth
                @if(auth()->user()->isAdmin() || auth()->user()->isManager())
                <li>
                    <a href="{{ route('components') }}" class="{{ request()->routeIs('components') ? 'active' : '' }}">
                        <i class="bi bi-collection"></i> <span>Components</span>
                    </a>
                </li>
                <li>
                    <a href="{{ route('tables') }}" class="{{ request()->routeIs('tables') ? 'active' : '' }}">
                        <i class="bi bi-table"></i> <span>Tables</span>
                    </a>
                </li>
                @endif

                <!-- Admin Only -->
                @if(auth()->user()->isAdmin())
                <li>
                    <a href="#">
                        <i class="bi bi-shield-lock"></i> <span>Admin Panel</span>
                    </a>
                </li>
                @endif

                <!-- Manager Only -->
                @if(auth()->user()->isManager())
                <li>
                    <a href="#">
                        <i class="bi bi-person-gear"></i> <span>Manager Panel</span>
                    </a>
                </li>
                @endif
            @endauth

            <li>
                <a href="{{ route('profile.edit') }}">
                    <i class="bi bi-person"></i> <span>Profile</span>
                </a>
            </li>
        </ul>
    </div>
</div>

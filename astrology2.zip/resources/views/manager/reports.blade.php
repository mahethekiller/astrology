@extends('layouts.app')

@section('title', 'Manager Reports')
@section('page-title', 'Manager Reports')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="component-card">
            <h4>Team Performance Reports</h4>
            <p>Manager-specific reports and analytics will be displayed here.</p>
        </div>
    </div>
</div>
@endsection

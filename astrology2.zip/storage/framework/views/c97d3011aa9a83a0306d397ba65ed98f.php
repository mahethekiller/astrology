<?php $__env->startSection('title', 'Data Tables'); ?>
<?php $__env->startSection('page-title', 'Data Tables'); ?>

<?php $__env->startSection('content'); ?>
<div class="table-container mb-4">
    <div class="table-header">
        <h3>Users Table</h3>
        <button class="btn btn-primary btn-sm">Export</button>
    </div>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user['id']); ?></td>
                    <td><?php echo e($user['name']); ?></td>
                    <td><?php echo e($user['email']); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($user['role'] == 'Admin' ? 'primary' : ($user['role'] == 'Manager' ? 'warning' : 'secondary')); ?>">
                            <?php echo e($user['role']); ?>

                        </span>
                    </td>
                    <td>
                        <span class="badge bg-<?php echo e($user['status'] == 'active' ? 'success' : 'warning'); ?>">
                            <?php echo e(ucfirst($user['status'])); ?>

                        </span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp2024\htdocs\astrology\resources\views/tables.blade.php ENDPATH**/ ?>
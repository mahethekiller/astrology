<?php
    // Get sliders for the specified group
    $sliders = \App\Models\Slider::active()->group($group)->ordered()->get();
?>

<?php if($sliders->count() > 0): ?>
<div id="<?php echo e($sliderId); ?>" class="carousel slide homeSliderStyle" data-bs-ride="carousel">
    <?php if($sliders->count() > 1): ?>
    <div class="carousel-indicators">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button type="button" data-bs-target="#<?php echo e($sliderId); ?>" data-bs-slide-to="<?php echo e($index); ?>"
                class="<?php echo e($index === 0 ? 'active' : ''); ?>" aria-current="<?php echo e($index === 0 ? 'true' : 'false'); ?>"
                aria-label="Slide <?php echo e($index + 1); ?>"></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <div class="carousel-inner">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
            <img src="<?php echo e(Storage::url($slider->image)); ?>" class="d-block w-100" alt="<?php echo e($slider->title); ?>">
            <?php if($slider->title || $slider->description || $slider->button_text): ?>
            <div class="carousel-caption d-none d-md-block">
                <?php if($slider->title): ?>
                <h5><?php echo e($slider->title); ?></h5>
                <?php endif; ?>
                <?php if($slider->description): ?>
                <p><?php echo e($slider->description); ?></p>
                <?php endif; ?>
                <?php if($slider->button_text && $slider->button_link): ?>
                <a href="<?php echo e($slider->button_link); ?>" class="btn btn-primary"><?php echo e($slider->button_text); ?></a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if($sliders->count() > 1): ?>
    <button class="carousel-control-prev" type="button" data-bs-target="#<?php echo e($sliderId); ?>" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#<?php echo e($sliderId); ?>" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
    <?php endif; ?>
</div>
<?php else: ?>
<!-- Fallback if no sliders found -->
<div id="<?php echo e($sliderId); ?>" class="carousel slide homeSliderStyle">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="<?php echo e(asset('frontend/images/banner.jpg')); ?>" class="d-block w-100" alt="Default Banner">
        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH D:\xampp2024\htdocs\astrology\resources\views/frontend/components/slider.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">Admin Dashboard</div>

                    <div class="card-body">
                        <h4>Welcome, <?php echo e(auth()->user()->name); ?>!</h4>
                        <p>You have administrator privileges.</p>
                        <ul>
                            <li>Manage Users</li>
                            <li>System Configuration</li>
                            <li>All Access</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp2024\htdocs\astrology\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
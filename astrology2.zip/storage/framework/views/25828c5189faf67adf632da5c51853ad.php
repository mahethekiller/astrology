<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $astrologers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $astrologer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-4">
            <div class="topAstroBox">
                <?php if($astrologer->is_online): ?>
                    <span class="topAstroBoxactive"></span>
                <?php else: ?>
                    <span class="topAstroBoxactive" style="background-color: gray;"></span>
                <?php endif; ?>
                <div class="flowBtn"> <a class="" href="#">Follow </a></div>
                <div class="retingStar"><i class="fa-solid fa-star"></i> <?php echo e(number_format($astrologer->rating, 1)); ?></div>
                <div class="topAstroBoxImg">
                    <a href="<?php echo e(route('astrologer.show', $astrologer->id)); ?>">
                        <img class="img-responsive" width="100" height="100" style="border-radius:50%; object-fit:cover;"
                            src="<?php echo e(asset('uploads/astrologers/' . $astrologer->profile_image)); ?>" />
                    </a>
                </div>
                <div class="astroDetails">
                    <div class="topAstroName text-truncate" title="<?php echo e($astrologer->display_name); ?>">
                        <?php echo e($astrologer->display_name); ?></div>

                    <div class="astroLang text-truncate" title="<?php echo e($astrologer->languages->pluck('name')->join(', ')); ?>">
                        <?php echo e($astrologer->languages->pluck('name')->join(', ')); ?></div>
                    <div class="topAstroWork text-truncate"
                        title="<?php echo e($astrologer->specializations->pluck('name')->join(', ')); ?>">
                        <?php echo e($astrologer->specializations->pluck('name')->join(', ')); ?></div>
                    <div class="totalExp">Exp. : <strong><?php echo e($astrologer->experience_years); ?> Yrs</strong></div>
                    <div class="astroCallorChatbtn">
                        <a class="astrochaybtn" href="#">
                            <img src="<?php echo e(asset('images/live-chat.png')); ?>" />
                            <?php if($astrologer->chat_price > 0): ?>
                                <?php echo e(number_format($astrologer->chat_price, 0)); ?>/Min
                            <?php else: ?>
                                NA
                            <?php endif; ?>
                        </a>
                        <a class="astrochaybtn" href="#">
                            <img src="<?php echo e(asset('images/live-call.png')); ?>" />
                            <?php if($astrologer->call_price > 0): ?>
                                <?php echo e(number_format($astrologer->call_price, 0)); ?>/Min
                            <?php else: ?>
                                NA
                            <?php endif; ?>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 text-center">
            <h4>No astrologers found matching your criteria.</h4>
        </div>
    <?php endif; ?>
</div>

<div class="row">
    <div class="col-12 d-flex justify-content-center">
        <?php echo e($astrologers->links('pagination::bootstrap-5')); ?>

    </div>
</div><?php /**PATH D:\xampp2024\htdocs\astrology\resources\views/frontend/astrologer/partials/astrologer-list.blade.php ENDPATH**/ ?>
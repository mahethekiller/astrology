<div class="header">
    <div class="header-left">
        <button class="mobile-menu-btn">
            <i class="bi bi-list"></i>
        </button>
        <h1><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></h1>
    </div>
    <div class="header-right">
        <div class="search-box">
            <i class="bi bi-search"></i>
            <input type="text" placeholder="Search...">
        </div>
        <button class="theme-toggle" id="themeToggle">
            <i class="bi bi-moon"></i>
        </button>
        <div class="user-profile dropdown">
            <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
                <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode(auth()->user()->name)); ?>&background=4361ee&color=fff" alt="User">
                <div>
                    <div class="fw-bold"><?php echo e(auth()->user()->name); ?></div>
                    <small class="text-muted">
                        <?php if(auth()->guard()->check()): ?>
                            <?php echo e(auth()->user()->getRoleNames()->first() ?? 'User'); ?>

                        <?php else: ?>
                            Guest
                        <?php endif; ?>
                    </small>
                </div>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>"><i class="bi bi-person me-2"></i>Profile</a></li>
                <li><hr class="dropdown-divider"></li>
                <li>
                    <form method="POST" action="<?php echo e(route('logout')); ?>" id="logout-form">
                        <?php echo csrf_field(); ?>
                        <a class="dropdown-item" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="bi bi-box-arrow-right me-2"></i>Logout
                        </a>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp2024\htdocs\astrology\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>